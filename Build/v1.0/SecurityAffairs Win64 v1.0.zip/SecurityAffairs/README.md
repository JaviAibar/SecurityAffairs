# SecurityAffairs

Juego realizado por [Adrian Castelló Martínez](https://www.linkedin.com/in/adri%C3%A1n-castell%C3%B3-mart%C3%ADnez-70909716b/ "Adrian Castelló Martínez") y yo [Javier Aibar Armero](https://www.linkedin.com/in/javier-aibar-armero-99b660117/ "Javier Aibar Armero") en **10 horas** para la mini GameJam de los Talleres de videojuegos de la UPV en 2019
Tema de la mini GameJam: 10 segundos

El juego consiste en seleccionar los elementos que están fuera de lugar o tienen algo de paranormal
